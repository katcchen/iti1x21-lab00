import org.junit.AfterClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import static org.junit.Assert.*;

public class TestHelloWorld {

    private static double grade = 0.0;

    @Rule
    public Timeout globalTimeout = Timeout.seconds(1); // 1 seconds max per method tested


    @AfterClass
    public static void afterClass() {

        System.out.println(TestUtils.DIV);

        System.out.println("Grade for HelloWorld (out of possible 1.0): " + grade);

        System.out.println(TestUtils.DIV);

    }
    @Test
    public void testSayHello() {
        assertEquals("sayHello() did not return the desired string", "Hello World", HelloWorld.sayHello());
        grade += 1.0;
    }

    public static void main(String[] args) {
        TestUtils.runClass(TestHelloWorld.class);
    }
}
